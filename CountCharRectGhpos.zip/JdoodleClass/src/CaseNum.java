public class CaseNum{
    public static void main(String args[]) {
        double sizes[] = {5.6, 8.1, 20.3, 2.6};
        double newSizes[]; // call the method
        double val1, val2, result;
        
        val1 = 5.5;
        val2 = 8.5;
        result = max(val1, val2);
        
        System.out.println("result: " + result);
    
    }

    public static int max(int num1, int num2) {
        if (num1> num2){
            return num1;
        }
        return num2;
    }

    public static double max(double num1, double num2) { // type different
        if (num1> num2){
            return num1;
        }
        return num2;
    }
}
    

     
