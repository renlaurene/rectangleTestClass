class Rectangle{
	double length;
	double width;
	Rectangle(double len, double wid){
		length = len;
		width = wid;
	}
}
public class RectangleClass {
    public static void main(String args[]){
        Rectangle newRect;
        Rectangle rect1; 
        
        rect1 = new Rectangle (15.6, 100.87);
        newRect = increaseDimensions(rect1, 20.0);       
        System.out.println("length: " + rect1.length);
        System.out.println("width: " + rect1.width);        
        System.out.println("length: " + newRect.length);
        System.out.println("width: " + newRect.width);
    }
    /* Add new method here */   
public static Rectangle increaseDimensions(Rectangle rect, double percentToIncrease){
        double curWidth, newWidth;
        double curLen, newLen; 
        double changeFactor;
        Rectangle largerRect;
        
        changeFactor = (percentToIncrease / 100) + 1.0;
        newWidth = rect.width * changeFactor;
        newLen = rect.length * changeFactor;
        
        largerRect = new Rectangle(newLen, newWidth);
        return largerRect;
    }
}


