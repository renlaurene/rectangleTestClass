class Rectangle1{
	double length;
	double width;
	
	Rectangle1(double len, double wid){
		length = len;
		width = wid;
	}
}
public class CreateRectClass {
    public static void main(String args[]){
        Rectangle1 rect1; 
        
        rect1 = new Rectangle1 (15.6, 100.87);
        increaseDimensions(rect1);
        
        System.out.println("length: " + rect1.length);
        System.out.println("width: " + rect1.width);
    }
    /* Add new method here */ 
    public static void increaseDimensions(Rectangle1 rect){
        double curWidth, newWidth;
        double curLen, newLen; 
        
        curWidth = rect.width;
        curLen = rect.length;
       
        newWidth = curWidth * 1.1;
        newLen = curLen * 1.1;
        
        rect.width = newWidth;
        rect.length = newLen; 
        
    }

}


