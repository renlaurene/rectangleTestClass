public class Methods1{
    public static void main(String args[]){
        double sizes[] = {5.6, 8.1, 20.3, 2.6};
        double newSizes[]; // call the method
        newSizes = adjustAry(sizes);
        for(int i=0; i<sizes.length; i++){
            System.out.println(newSizes[i]);
        }
    }
    /* Add new method here returning double[] */ 
    public static double[] adjustAry(double dblary[])
    {//Function prototype : data type, parameter header--then following body
        int lastIdx;
        double aryCpy[];        
        aryCpy = new double[dblary.length];  /* instantiate an array of same size */      
        for(int i=0; i<dblary.length; i++){ /* for loop to copy element of array */ 
            aryCpy[i] = dblary[i];
        } 
        /* modify first and last element of new array */    
        aryCpy[0] = aryCpy[0] + 1.1;
        lastIdx = dblary.length - 1; 
        aryCpy[lastIdx] = aryCpy[lastIdx] + 1.1;
        
        return aryCpy;
    }
}