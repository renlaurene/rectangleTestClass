public class AryCpyMethod{
    public static void main(String args[]){
        double sizes[] = {5.6, 8.1, 20.3, 2.6};
        double newSizes[]; // call the method
        newSizes = adjustAry(sizes);
        for(int i=0; i<sizes.length; i++){
            System.out.println(newSizes[i]);
        }
    }
    
    /* Add new method here */
    public static double[] adjustAry(double dblary[]) // Function prototype : datatype, parameter header--body following then // returning doubel[]
    {
        int lastIdx;
        double aryCpy[]; 
        /* instantiate an array of same size */ 
        aryCpy = new double[dblary.length];     
        /* for loop to copy element of array */      
        for(int i=0; i<dblary.length; i++){
            aryCpy[i] = dblary[i];
        }      
        /* modify first and last element of new array */      
        aryCpy[0] = aryCpy[0] + 1.1;
        lastIdx = dblary.length - 1; 
        aryCpy[lastIdx] = aryCpy[lastIdx] + 1.1;   
        return aryCpy;
    }
}