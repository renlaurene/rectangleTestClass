public class CountChara {
    public static void main(String args[]) {
        String tststr = " t2q3abbt4ay";
        int strlen;
        char tstChar;
        char prevChar;
        int count;
        
        count = 0; 
        strlen= tststr.length();
        prevChar = tststr.charAt(0);
        if (prevChar == 'z'){
            return; 
        }
        
        for (int i = 0; i < strlen; i++){
            //prevChar = tststr.charAt(i-1);
            tstChar = tststr.charAt(i);
            if(tstChar == 'z'){
                break;
            }
            if (Character.isDigit(prevChar) && tstChar == 'a'){
                count++;
            }
            prevChar = tstChar; 
        }
        System.out.println("count" + count);
    }
}
    


